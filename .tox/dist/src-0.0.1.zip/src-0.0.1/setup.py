from setuptools import setup, find_packages

setup(
    name="src", version="0.0.1",
    description="This is a CNN classification with DVC tracking",
    author="Monalsingh",
    packages=find_packages(),
    license="MIT"

)