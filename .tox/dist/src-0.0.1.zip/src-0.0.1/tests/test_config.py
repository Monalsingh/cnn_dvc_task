
def test_generic():
    a=1
    b=1
    assert a == 1